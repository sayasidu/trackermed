repo: sayasidu/trackermed
branch: main

## Last sync
date: 2026-07-26T21:53:19Z

### Updated in this project
- Recriação do Dashboard e do Histórico do TrackerMed a partir do código real (app.css, dashboard.html, historico.html, index.html).
- Nova proposta de app para iPhone (protótipo navegável) e iPad, mantendo a identidade Cobalto.
- Desenho do fluxo de conta + sincronização na nuvem e do estado offline (hoje os dados vivem só em localStorage).

## Screen map
| Tela do projeto | Arquivos do repositório |
| --- | --- |
| TrackerMed App.dc.html · iPhone Home (9 atalhos) | index.html, app.css |
| TrackerMed App.dc.html · iPhone Dashboard | dashboard.html, app.css |
| TrackerMed App.dc.html · iPhone Histórico + cronômetro | historico.html, app.css |
| TrackerMed App.dc.html · iPhone Conta e sincronização | index.html (chaves localStorage), dashboard.html |
| TrackerMed App.dc.html · iPad Dashboard (sidebar + 2 colunas) | dashboard.html, app.css |

## Chaves de dados hoje (localStorage, por navegador)
trackermed.nome.v1 · trackermed.prova.v1 · trackermed.plan.v1 ·
trackermed.disciplinas.v1 · trackermed.erros.v1 · trackermed.simulados.v2
